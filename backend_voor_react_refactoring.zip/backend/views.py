from django.shortcuts import render
from django.views import generic
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import requires_csrf_token
from django.core.urlresolvers import reverse_lazy
from django.contrib.auth import logout

# Create your views here.
@method_decorator(login_required, name='dispatch')
class AnalyseView(generic.base.TemplateView):
    
    template_name = 'templates/analyse/analyse.html'

    def get_context_data(self, **kwargs):
        context = super(AnalyseView, self).get_context_data(**kwargs)
        context['csv_data'] = "CSV_Data"
        return context    

class ChartView(generic.base.TemplateView):
    template_name = 'templates/analyse/chart.html'

class BeheerView(generic.base.TemplateView):
    print("In Beheer View")
    template_name = 'beheer.html'

class LoginView(generic.base.TemplateView):
    print("In LoginView")
    template_name = 'login.html'
#     success_url = reverse_lazy('analyse')


class TrendView(generic.base.TemplateView):
    
    template_name = 'trend.html'