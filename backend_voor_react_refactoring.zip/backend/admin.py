from django.contrib import admin

# Register your models here.
from .models import AgendaItem, DataSet

admin.site.register(AgendaItem)
admin.site.register(DataSet)