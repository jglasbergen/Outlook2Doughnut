var React = require('react')
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import {Card, CardActions, CardHeader, CardMedia, CardTitle, CardText} from 'material-ui/Card';
import FlatButton from 'material-ui/FlatButton';
import { Chart } from 'react-google-charts';

export default class Analyse extends React.Component {
    constructor(props) {
        super(props);

        this.state = { 
            username: props.username,
            dataset: 'Current Dataset',
            title: 'Analyse',
            options:    {title: 'Outlook Categorieën', 
                            pieHole: 0.4,
                            // slices: {
                            //             '5': {'offset': 0.2}
                            //         }
                        },
            data:[
                    ['Categorie', 'Percentage'],
                    ['Werven vrijwilligers', 9.41],
                    ['Medewerkers trainen op positieve houding', 16.47],
                    ['Pauze', 5.88],
                    ['Proces samen een probleem oplossen verbeteren', 12.94],
                    ['Uitbreiden dagbestedingsactiviteiten', 9.41],
                    ['Werkvloeren', 20],
                    ['Overig (geen doel in Hoshin)', 18.82]
                ],
            chart_events: [
                {
                    eventName : 'select',
                    callback  : (Chart) => { 
                        var selectedItem = Chart.chart.getSelection()[0];
                        if (selectedItem) {
                            console.log("Selected Item", selectedItem.row); 
                            var slice_nummer = selectedItem.row;
                            // Uitwerken hoe de slice uitgenomen kan worden op basis van de selectie!
                            Chart.chart.setSelection({options: {slices: {slice_nummer:{ 'offset': 0.2} }}});
                        } else {
                            // Er is geklikt, maar er is blijkbaar geen item om mee te werken!
                            console.log("Chart", Chart); 
                        }
                    }
                }
                ]
            };
        }
    
    render() {
        return (
            <MuiThemeProvider>
                <Card>
                    <CardTitle title={this.state.title} subtitle={this.state.dataset} />
                    <CardText>
                        <Chart 
                            chartType='PieChart'
                            options={this.state.options}
                            data={this.state.data}
                            width="90vw"
                            height="50vh"
                            chartEvents={this.state.chart_events}
                            />
                    </CardText>
                    {/* <CardActions>
                        <Button label="Action1" />
                        <Button label="Action2" />
                    </CardActions> */}
                </Card>
            </MuiThemeProvider>
        );
    }


}

