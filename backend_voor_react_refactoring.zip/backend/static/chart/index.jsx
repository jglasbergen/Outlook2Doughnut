var React = require('react');
var ReactDOM = require('react-dom');
import Analyse from './chart';

// Parameter passed by chart.html
const current_user = document.getElementById('analyse').getAttribute("username");

const AnalyseCard = () => {
    return (
        <div>
            <Analyse username={current_user}/>
        </div>
    )
}

ReactDOM.render(
    <AnalyseCard />,
    document.getElementById('analyse')
);
